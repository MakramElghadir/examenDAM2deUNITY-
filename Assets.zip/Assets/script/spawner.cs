using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour
{

    [SerializeField]
    private GameObject swarmerMediumPrefab;
    [SerializeField]
    private GameObject swarmerLightPrefab;
    [SerializeField]
    private GameObject swarmerHeavyPrefab;


    [SerializeField]
    private float swarmerInterval = 4.5f;
    [SerializeField]
    private float swarmerLightInterfal = 2.5f;
    [SerializeField]
    private float swarmerHeavyInterfal = 8f;

    [SerializeField]
    private GameObject[] choosenPrefab;
    [SerializeField]
    private float choosenInterfal = 1f;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(spawnEnemy());
    }

    private IEnumerator spawnEnemy() {

        while (true)
        {
            var choice = Random.Range(0, 2);
            choosenInterfal = Random.Range(1, 3);
            GameObject newEnemy = Instantiate(choosenPrefab[Random.Range(0, choosenPrefab.Length)]);

            yield return new WaitForSeconds(choosenInterfal);

        }

        
    }
}
